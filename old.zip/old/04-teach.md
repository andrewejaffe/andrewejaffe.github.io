---
layout: page
title: Teaching
group: navigation
permalink: "teaching.html"
---
{% include JB/setup %}

Courses
-------------

[Introduction to R for Public Health Researchers (Summer 2016)](http://www.aejaffe.com/summerR_2016/). Johns Hopkins University, Baltimore MD

[Introduction to R for Public Health Researchers (Winter 2016)](http://www.aejaffe.com/winterR_2016/). Johns Hopkins University, Baltimore MD

[Introduction to R for Public Health Researchers (Summer 2015)](http://www.aejaffe.com/summerR_2015/). Johns Hopkins University, Baltimore MD

[SISBID Module 1: Big Data Wrangling (Summers 2016-2018)](http://sisbid.github.io/Module1/). University of Washington, Seattle WA
